var bankApp = angular.module('myApp');

bankApp.controller('AppCtrl', function ($scope) {
    $scope.name = 'James';
    });