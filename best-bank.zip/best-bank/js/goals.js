'use strict';
/*global angular*/
var goalApp = angular.module('goalApp', ['ngRoute','ngMaterial', 'ngAnimate', 'ngMessages','angular-carousel']);
var goals = [{
    itemDescription: 'Bike',
    //image:"../images/small-zebra-icon.png",
    image:null,
    dateCreated: new Date(),
    targetAmount: 100,
    currentAmount:0,
    priority:3,
    dueDate:new Date(),
    description:'some description'
},
   {itemDescription:'Shirt',
    image:null,
    dateCreated: new Date(),
   targetAmount:150,
   currentAmount:50,
   priority:2,
    dueDate:new Date(),
    description:'some description'
   }];


goalApp.controller('GoalController', ['$scope', function($scope) {
 $scope.userBankBalance=1000;
  $scope.showAddGoalForm=false;
  $scope.showAddGoalButton=true;
  $scope.showAddGoalCarousel=true;
  $scope.goalList=goals;
    $scope.currentAmount=0;
    
    $scope.resetValues=function(){
        $scope.itemDescription='';
        $scope.dateCreated='';
        $scope.targetAmount=null;
        $scope.priority='';
        $scope.dueDate='';
        $scope.image='';
        $scope.description='';
    };
  
    
  $scope.addGoal=function(){
      $scope.inputGoal = {itemDescription:$scope.itemDescription, 
                          image:$scope.image, 
                          dateCreated: $scope.dateCreated, 
                          targetAmount:$scope.targetAmount, 
                          currentAmount:$scope.currentAmount, 
                          priority:$scope.priority, 
                          dueDate:$scope.dueDate, 
                          description:$scope.description};
      $scope.goalList.push($scope.inputGoal);
  };
    
    $scope.depositToGoal=function(index,amount){
        if($scope.userBankBalance>amount && $scope.goalList[index].currentAmount<$scope.goalList[index].targetAmount){
        $scope.goalList[index].currentAmount+=amount;
            $scope.userBankBalance-=amount;
        }  
         console.log($scope.userBankBalance);
    };
    
    $scope.withdrawFromGoal=function(index,amount){
        if(amount>$scope.currentAmount){
            $scope.userBankBalance+=$scope.goalList[index].currentAmount;
            $scope.goalList[index].currentAmount=0;
        }else{
            $scope.userBankBalance+=amount;
            $scope.goalList[index].currentAmount-=amount;
        }
        
        console.log($scope.userBankBalance);
           // $scope.userBankBalance-=amount;
    };
    $scope.showAddGoalFormFunc=function(showForm,showButton,showCarousel){
        $scope.showAddGoalForm=showForm;
        $scope.showAddGoalButton=showButton;
        $scope.showAddGoalCarousel=showCarousel;
    };
    
}]);





